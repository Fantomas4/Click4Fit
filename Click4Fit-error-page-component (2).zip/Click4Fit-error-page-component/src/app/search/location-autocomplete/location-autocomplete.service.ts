import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LocationAutocompleteService {

  constructor() { }

  getAvailableCountries() {}

  getAvailableCities() {

  }
}
