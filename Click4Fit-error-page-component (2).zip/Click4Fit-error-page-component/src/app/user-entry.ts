export interface UserEntry {
    id: number;
    name: string;
    lastname: string;
    email: string;
    password: string;
    birthdate: string;
}
