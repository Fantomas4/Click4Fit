export interface LegsWorkoutEntry{
    id: number;
    name: string;
    advisedFor: string;
    levelOfDifficulty: string;
    equipment: string;
    sets: string;
    video: string;
}
export interface BackWorkoutEntry{
    id: number;
    name: string;
    advisedFor: string;
    levelOfDifficulty: string;
    equipment: string;
    sets: string;
    video: string;
}
export interface ChestWorkoutEntry{
    id: number;
    name: string;
    advisedFor: string;
    levelOfDifficulty: string;
    equipment: string;
    sets: string;
    video: string;
}
export interface ShouldersWorkoutEntry{
    id: number;
    name: string;
    advisedFor: string;
    levelOfDifficulty: string;
    equipment: string;
    sets: string;
    video: string;
}
export interface BicepsWorkoutEntry{
    id: number;
    name: string;
    advisedFor: string;
    levelOfDifficulty: string;
    equipment: string;
    sets: string;
    video: string;
}
export interface TricepsWorkoutEntry{
    id: number;
    name: string;
    advisedFor: string;
    levelOfDifficulty: string;
    equipment: string;
    sets: string;
    video: string;
}
export interface AbsWorkoutEntry{
    id: number;
    name: string;
    advisedFor: string;
    levelOfDifficulty: string;
    equipment: string;
    sets: string;
    video: string;
}
export interface CoreWorkoutEntry{
    id: number;
    name: string;
    advisedFor: string;
    levelOfDifficulty: string;
    equipment: string;
    sets: string;
    video: string;
}